package com.perfume.beans;

import lombok.Data;

@Data
public class AdminDTO {
	private String aid;
	private String pw;
	private String auth;
}
