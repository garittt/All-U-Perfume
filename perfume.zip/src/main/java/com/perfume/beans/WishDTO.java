package com.perfume.beans;

import lombok.Data;

@Data
public class WishDTO {
	
	private String writer;
	private String f_number;
	

}
