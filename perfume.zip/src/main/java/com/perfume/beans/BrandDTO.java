package com.perfume.beans;

import lombok.Data;

@Data
public class BrandDTO {
	
	private String d_name;
	private String d_pic;
	private String d_picsmall;
	private String d_number;
	private String d_country;
	

}
